# practica6
